''' example run:
python .\article_pipeline.py -r 20 -q "Hezbollah OR Hizbollah OR Hizbullah OR Hizballah OR 'Asaib Ahl al-Haq'"
'''

# python
from datetime import datetime, timedelta
import time
import sys
import logging  
logging.basicConfig(level=logging.INFO)  
log = logging.getLogger(__name__)
import argparse

# project
import scraper
import position


def parse_args(args):
    parser = argparse.ArgumentParser(
        description='arguments to provide to transform.main()',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument('-q', '--query', dest="query", default='', help='provide boolean search term, phrase or set')
    parser.add_argument('-u', '--urls', dest="urls", default=[], nargs="+", help='provide list of URLs to be scraped')
    parser.add_argument('-k', '--keywords', dest="keywords", default=[], nargs="+", help='provide list of keywords for relative position analysis')
    parser.add_argument('-t', '--threads', dest="n_threads", default=40)
    parser.add_argument('-r', '--results', dest="n_results", default=10)
    
    return parser.parse_args(args)


def main(args):
    log.info('pipeline start time: {}'.format(datetime.now().strftime("%Y-%m-%d-%H.%M.%S")))
    start_time = time.time()
    
    pargs = parse_args(args)
    log.info(pargs)
    
    scraper.process(pargs.query, pargs.urls, pargs.keywords, int(pargs.n_threads), int(pargs.n_results))
    position.process(pargs.keywords)
    
    log.info('pipeline finished. end time: {}'.format(datetime.now().strftime("%Y-%m-%d-%H.%M.%S")))
    log.info('pipeline completed in {}'.format(timedelta(seconds=int(time.time() - start_time))))


if __name__ == '__main__':
    main(sys.argv[1:])

