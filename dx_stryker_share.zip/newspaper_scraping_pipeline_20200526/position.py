import pandas as pd
import numpy as np
from ast import literal_eval
import re
from textblob import TextBlob


def literal_return(val):
    try:
        return literal_eval(val)
    except (ValueError, SyntaxError) as e:
        return val


def process(keywords = None):
    articles_df = pd.read_csv('./articles_output.csv')
    articles_df.quotes = articles_df.quotes.apply(lambda x: literal_return(str(x)))


    # split quotes into columns
    quote_df = articles_df[['url', 'quotes']]
    quote_df = quote_df.quotes.apply(pd.Series) \
        .merge(quote_df, left_index = True, right_index = True) \
        .drop(["quotes"], axis = 1) \
        .melt(id_vars = ['url'], value_name = "quote") \
        .dropna() \
        .drop("variable", axis = 1) \
        .reset_index(drop=True)
        
    # to explode dictionary
    # quote_df = quote_df.rename(columns={'quote':'quote_dict'})
    # quote_df.join(quote_df.quote_dict.apply(pd.Series))


    # split sentences into columns
    sent_df = articles_df[['url', 'rel_sents']]
    sent_df = sent_df.rel_sents.apply(pd.Series) \
        .merge(sent_df, left_index = True, right_index = True) \
        .drop(["rel_sents"], axis = 1) \
        .melt(id_vars = ['url'], value_name = "rel_sents") \
        .dropna() \
        .drop("variable", axis = 1) \
        .reset_index(drop=True)
        
    # select only the split columns' rows if others cannot be filtered out
    # quote_df = quote_df[quote_df.variable.apply(lambda x: isinstance(x, (int)))]

    # get rid of fails
    quote_df = quote_df[quote_df.quote != 'fail']

    # get rid of empties
    sent_df = sent_df[sent_df.rel_sents != 'none']

    def clean_keys(dict_cur):
        new_dict = {}
        for k, v in dict_cur.items():
            new_dict[re.sub(r'\d+', '', str(k))] = v
        return new_dict

    quote_df.quote = quote_df.quote.apply(clean_keys)

    # source: https://medium.com/swlh/simple-sentiment-analysis-for-nlp-beginners-and-everyone-else-using-vader-and-textblob-728da3dbe33d
    # setup:
    # pip install -U textblob
    # python -m textblob.download_corpora

    # set sentiment column when keywords appear in the quote
    quote_df['position'] = np.NaN
    quote_df['position'] = quote_df.apply(lambda x: TextBlob(x['quote']['quote']).sentiment.polarity \
    if not keywords or any([keyword for keyword in keywords if keyword in x['quote']['quote'].lower()]) \
    else x['position'], axis=1)
    quote_df['speaker'] = quote_df['quote'].apply(lambda x: x['speaker'].strip())
    quote_df['quote'] = quote_df['quote'].apply(lambda x: x['quote'].strip())
    quote_df.to_csv('quotes.csv')
    # or sentence
    sent_df['position'] = np.NaN
    sent_df['position'] = sent_df.apply(lambda x: TextBlob(x['rel_sents']).sentiment.polarity \
    if not keywords or any([keyword for keyword in keywords if keyword in x['rel_sents'].lower()]) \
    else x['position'], axis=1)
    # quote_df['speaker'] = quote_df['rel_sents'].apply(lambda x: x['speaker'])
    # quote_df['rel_sents'] = quote_df['rel_sents'].apply(lambda x: x['rel_sents'])
    sent_df.to_csv('sentences.csv')

    quote_mean_df = quote_df.groupby(['url']).mean()
    sent_mean_df = sent_df.groupby(['url']).mean()
    df_means = pd.merge(quote_mean_df, sent_mean_df, on=['url'])
    df_means['pos_mean'] = df_means.mean(axis=1)
    df_final = pd.merge(articles_df, df_means, on=['url'])
    df_final.to_csv('position_results.csv')
