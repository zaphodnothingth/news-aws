# APIs
import requests
from newspaper import Article, fulltext
import random
user_agent_list = [
   #Chrome
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36','Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','Mozilla/5.0 (Windows NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36','Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36','Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36','Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
    #Firefox
    'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)','Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko','Mozilla/5.0 (Windows NT 6.2; WOW64; Trident/7.0; rv:11.0) like Gecko','Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0)','Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)','Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko','Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)','Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)'
]
from googlesearch import search_news

# logging
import logging
log = logging.getLogger(__name__)

# general python 
import time
import sys
import re
import json
from datetime import datetime, timedelta
from unidecode import unidecode
import csv
columns = ['url', 'body', 'title', 'summary', 'keywords', 'authors3k', 'pubdate', 'quotes', 'rel_sents']

# nlp. download language package outside of shell before running
# python -m spacy download en_core_web_sm
import spacy
nlp = spacy.load("en_core_web_sm")

# multithreading
import threading
import queue
global lck 
lck = threading.Lock()

# start forreal



def collect_urls(query, n_results):
    results_list = []
    for i in search_news(query,   # The query you want to run
    #                tld = 'com',  # The top level domain
                    lang = 'en',  # The language
                    num = 100,     # Number of results per page - 10, 25, 50, 100
                    start = 0,    # First result to retrieve
                    stop = n_results,  # Last result to retrieve
                    pause = 2.0,  # Lapse between HTTP requests
                   ):
        results_list.append(i)
    skips = ['videos'] # sites that don't contain article content
    results_list = [item for item in results_list if not any([skip for skip in skips if skip in item])]
    log.info('links to attack: {}'.format(results_list))
    return results_list


class Worker(threading.Thread):


    def __init__(self, q, i, *args, **kwargs):
        self.q = q
        self.i = i
        super().__init__(*args, **kwargs)
        
        
    def run(self):
        while True:
            try:
                j, url, keywords = self.q.get(timeout=3)  # 3s timeout
                i = self.i
            except queue.Empty:
                return
            
            article_dict = {}
            try:
                article_dict['url'] = url
                log.info('[t{}] {}- processing\n\tlink: {}'.format(i, j, url))
                # randomize user agents
                user_agent = random.choice(user_agent_list)
                headers = {'User-Agent': user_agent}
                article = requests.get(url, headers=headers)
                article_orig = article
                # nespaper3k processing
                article = Article(url)
                article.download()
                article.parse()
                article.nlp()
                
                article_dict['title'] = article.title
                article_dict['summary'] = article.summary
                article_dict['keywords'] = article.keywords
                article_dict['authors3k'] = article.authors
                article_dict['pubdate'] = article.publish_date
                body = ''
                try:
                    body = article.text
                except:
                    body = 'fail'

                try:
                    html_body = article_orig.text
                    body = fulltext(html_body)
                except:
                    body = 'fail'
                    
                article_dict['body'] = body
                
            except:
                log.error('\n\n[t{}] {}- error: \n\turl: {}\n\tdetails [line {}]:{}\n\n'.format(i, j, url, sys.exc_info()[-1].tb_lineno, sys.exc_info()[0]))
            
            # extract quotes from body, remove stuff like l & r quotes first
            body = unidecode(body)
            if len(body) > 5:
                # extract quotes
                quotes = []
                terms = ['said', 'say', 'state', 'argue', 'told', 'wrote', 'writ', 'tweet', 'announc']
                for term in terms:
                    r = re.compile(
                        r'''(?:"(?P<quote>[^"]+)"\W+(?i:{0}\w*)(?P<speaker>(?:\s(?:he|she|they|[A-Z]+[a-z.]*))+)(?:\s|(?:,(?P<title>(?:(?:\s[\w\']+))+)[,.])))|(?:"(?P<quote1>[^"]+)"(?P<speaker1>(?:\s(?:he|she|they|(?:[A-Z]+[a-z.]*\s)+))+)(?:\s?|(?:,(?P<title1>(?:(?:\s[\w\']+))+),))(?i:{0}\w*))|(?:(?P<speaker2>(?:he|she|they|(?:[A-Z]+[a-z.]*\s)+))(?:\s?|(?:,(?P<title2>(?:\s[\w\']+)+),\s))(?i:{0}\w*)\s(?:\w+\s)*"(?P<quote2>[^"]+)")|(?:(?i:{0}\w*)(?P<speaker3>[^"]+)"(?P<quote3>[^"]+)"\.)'''.format(term))
                    re_dicts = [m.groupdict() for m in r.finditer(body)]
                    for re_dict in re_dicts:
                        clean_dict = {k: v for k, v in re_dict.items() if v}
                        new_dict = {}
                        for k, v in clean_dict.items():
                            new_dict[re.sub(r'\d+', '', str(k))] = v
                        quotes.append(new_dict)
                # extract relevant sentences "about" the subject
                sentences = []
                if len(keywords) > 0:
                    for sentence in body.split('.'):
                        doc = nlp(sentence)
                        if any([keyword for keyword in keywords for token in doc if keyword in token.text.lower() and token.dep_ in ['dobj','attr']]):
                            sentences.append(sentence)
                if len(sentences) == 0:
                    sentences = 'none'
                        
                # clean out empty regex returns
                # quotes = [[item for item in tup if len(item)>0] for tup in quotes] # for tuples
                # clean out html junk; obselete since using newspaper3k to grab body
                # body = re.sub(r'#[\w\-\s.:()]+{[^}]+}', '', body)
                article_dict['quotes'] = json.dumps(quotes)
                article_dict['rel_sents'] = sentences
                log.info('[t{}] {}- success\n\turl: {}'.format(i, j, url))
                
            else:
                log.error('[t{}] {}- unsuccessful: \n\turl: {}'.format(i, j, url))
                for kee in columns:
                    if kee not in article_dict: article_dict[kee] = 'fail'
                
            lck.acquire()
            with open("articles_output.csv", 'a',encoding='utf-8-sig', newline='') as g:
                csv.DictWriter(g, fieldnames=columns).writerow(article_dict)
            lck.release()
            log.info('[t{}] {}- written\n\tlink: {}'.format(i, j, url))
            self.q.task_done()


def process(query=None, urls=[], keywords = [], n_threads: int =40, n_results=10):
    log.info('article scraping start time: {}'.format(datetime.now().strftime("%Y-%m-%d-%H.%M.%S")))
    start_time = time.time()
    
    if (query and len(urls)>0) or (not query and len(urls)==0):
        log.error('provide query or urls; not both or neither')
        sys.exit(1)
    
    log.info('query: {}'.format(query))
    url_list = collect_urls(str(query), int(n_results))
    if len(url_list) ==0:
        log.error('no news results found')
        sys.exit(1)
        
    log.info('URL count: {}'.format(len(url_list)))
    if len(url_list) < n_threads: n_threads = round(len(url_list)/4)

    with open("articles_output.csv", 'w',encoding='utf-8-sig', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=columns)
        writer.writeheader()
    
    q = queue.Queue()
    for k, link in enumerate(url_list):
        q.put_nowait((k, link, keywords))
    for _ in range(n_threads):
        Worker(q, _).start()
        time.sleep(1)
    q.join()
    
    log.info('article scraping finished. end time: {}'.format(datetime.now().strftime("%Y-%m-%d-%H.%M.%S")))
    log.info('article scraping completed in {}'.format(timedelta(seconds=int(time.time() - start_time))))

