# Standard libraries
import pandas as pd
from pathlib import Path
from datetime import datetime
import os
from itertools import islice


### NLP dependencies
import spacy
from langdetect import detect
from spacy.tokenizer import Tokenizer

# Sentiment analysis
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Get script runtime
import time
start_time = time.time()

# Initialize NLP
nlp = spacy.load('en_core_web_sm')
tokenizer = Tokenizer(nlp.vocab)
analyzer = SentimentIntensityAnalyzer()

# If grabbing from file
# Set data directory
fp_date = datetime.now().strftime("/%Y%m%d")
os.chdir("../data/")
DATA_DIRECTORY = str(Path("../data/").resolve())
# os.makedirs(DATA_DIRECTORY +  "/processed/" + fp_date)
print("Created the directory")
topic = "_mytopic"
PROCESSED_DATA_DIRECTORY = DATA_DIRECTORY + "/processed/" + fp_date
RAW_DATA_DIRECTORY = DATA_DIRECTORY + "/raw/" + fp_date
#Read comments
comment_fp = RAW_DATA_DIRECTORY + "comments.xlsx"
df = pd.read_excel(comment_fp)
#Read meta
meta_fp = RAW_DATA_DIRECTORY + "metadata.xlsx"
meta = pd.read_excel(meta_fp)

print(df.shape)
print(meta.shape)

''' Preprocess Data
CURRENTLY FORMATTED FOR YOUTUBE RAW OUTPUT
Replace "text" column with relevant column name for other social media platforms
Replace "url" column with relevant identifier for other social media platforms
'''
# Check NaN values, drop comment NaN values, drop duplicates
df.isna().sum()
df = df.dropna(subset = ["text"])
keep_urls = list(set(meta['url'].to_list()))
df = df[df['url'].isin(keep_urls)]

''' Detect Language
'''
print("Detecting language")
for index, row in df['text'].iteritems():
    try:
        df.loc[index, 'text_language'] = detect(row) #detecting each row
    except:
        df['text_language'] = 'en' #ENGLISH COMMENT DEFAULT
#Return language value counts
#df['text_language'].value_counts()

#Separate non-English comments in another data frame
nonen = df[df['text_language'] != 'en']

#Subset to english for analysis
df = df[df['text_language'] == 'en']

print(df.shape)
print(nonen.shape)

''' Extract Entities & Sentiment
'''
# Extract entities
orgs = []
names = []
locations = []
sentiments = []

print("Extracting entities")
for df_idx, df_row in df.iterrows():

    # Split sentences
    df_sents = df_row["text"].splitlines()

    # Sentiment analysis
    sentiment = analyzer.polarity_scores(df_row["text"])
    sentiments.append(sentiment["compound"])

    # Process entities
    org_train = []
    name_train = []
    location_train = []

    for sent_idx in range(len(df_sents)):
        doc = nlp(df_sents[sent_idx])

        for ent in doc.ents:
            if ent.label_ == "ORG":
                if not ent.text.capitalize() in org_train:
                    org_train.append(ent.text.capitalize())

            if ent.label_ == "PERSON" or ent.label_ == "NORP":
                if not ent.text.capitalize() in name_train:
                    name_train.append(ent.text.capitalize())

            if ent.label_ == "LOC" or ent.label_ == "GPE" or ent.label_ == "FAC":
                if not ent.text.capitalize() in location_train:
                    location_train.append(ent.text.capitalize())

    orgs.append(org_train)
    names.append(name_train)
    locations.append(location_train)
df["text_org"] = orgs
df["text_person_or_group"] = names
df["text_location"] = locations
df["text_sentiment"] = sentiments

#Write to Excel if needed
write_file_name = datetime.now().strftime("%Y-%m-%dT%H-%M-%S") + topic + "_processed_nosplit.xlsx"
write_path = PROCESSED_DATA_DIRECTORY + "/" + write_file_name
df.to_excel(str(write_path), index=False, na_rep='None', encoding="utf-16")
print("Exported file without entities split to Excel")

#Copy processed data frame for entity list splitting
processed = df.copy()

#Split entity list into two columns
def splitlists(l):
    length_to_split = [10, 10000]
    # l = literal_eval(l)
    inp = iter(l)
    split = [list(islice(inp, elem)) for elem in length_to_split]
    return split

top10o = []
o = []
for x_idx, x_row in processed.iterrows():
    split = splitlists(x_row['text_org'])
    top10o.append(split[0])
    if len(split) > 1:
        o.append(split[-1])
    else:
        o.append(None)


top10p = []
p = []
for processed_idx, processed_row in processed.iterrows():
    split = splitlists(processed_row['text_person_or_group'])
    top10p.append(split[0])
    if len(split) > 1:
        p.append(split[-1])
    else:
        p.append(None)


top10l = []
l = []
for processed_idx, processed_row in processed.iterrows():
    split = splitlists(processed_row['text_location'])
    top10l.append(split[0])
    if len(split) > 1:
        l.append(split[-1])
    else:
        l.append(None)

#Create column with first 10 entities in original entity list
processed['org_'] = top10o
processed['per_'] = top10p
processed['loc_'] = top10l

#Split first 10 items of entity list to columns then drop column
cols = ['org_' + str(i) for i in range(1,11)]
processed[cols] = pd.DataFrame(processed.org_.values.tolist(), index = processed.index)
processed = processed.drop(columns = ['org_'])
processed['org_11'] = o

cols = ['per_' + str(i) for i in range(1,11)]
processed[cols] = pd.DataFrame(processed.per_.values.tolist(), index = processed.index)
processed = processed.drop(columns = ['per_'])
processed['per_11'] = p

cols = ['loc_' + str(i) for i in range(1,11)]
processed[cols] = pd.DataFrame(processed.loc_.tolist(), index = processed.index)
processed = processed.drop(columns = ['loc_'])
processed['loc_11'] = l

#Bring back in non-English comments into processed dataframe
processed = processed.append(nonen, sort = False)

# Write to Excel
write_file_name = datetime.now().strftime("%Y-%m-%dT%H-%M-%S") + topic + "_processed_split.xlsx"
write_path = PROCESSED_DATA_DIRECTORY + "/" + write_file_name
processed.to_excel(str(write_path), index=False, na_rep='None', encoding="utf-16")
print("Exported to Excel")

rt = (time.time() - start_time)
print("Runtime: --- %s seconds ---" % rt)
print("Runtime: --- %s minutes ---" % rt/60)

