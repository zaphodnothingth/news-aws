import pandas as pd
import os
import praw
from praw.models import MoreComments
from datetime import datetime
from pathlib2 import Path

''' 
Set Up
- Create CSV output directory based on today's date
- Apply Reddit API credentials
'''
DATA_DIRECTORY = str(Path("../data/raw/").resolve())
os.makedirs(DATA_DIRECTORY + datetime.now().strftime("/%Y%m%d"))
TODAY_DIRECTORY = DATA_DIRECTORY + datetime.now().strftime("/%Y%m%d")
reddit = praw.Reddit(client_id='clientid',
                     client_secret='clientsecret',
                     user_agent='appname',
                     username='reddituser',
                     password='redditpass')
'''
Functions to collect Reddit Posts
'''
def search_reddit(search_term, sort_type, time_limit, post_limit):
    '''
    GRAB REDDIT POSTS BY SEARCH TERM
    search_term = any boolean search #https://www.reddit.com/dev/api/
    sort_type = 'relevance', 'hot', 'top', 'new', 'comments'
    time_limit = 'all', 'hour', 'day', 'week', 'month', 'year'
    post_limit = 1000 maximum
    '''
    posts = []
    subreddit = reddit.subreddit("all")
    for post in subreddit.search(search_term, sort=sort_type, time_filter=time_limit, limit=post_limit):
        posts.append([post.subreddit, post.id, post.title, post.selftext, post.author, post.url, post.permalink,
                      post.num_comments, post.created, post.score, post.distinguished, post.is_original_content,
                      post.upvote_ratio])
    posts = pd.DataFrame(posts,
                         columns=['subreddit', 'post_id', 'title', 'post_body', 'post_author', 'url', 'post_permalink',
                                  'num_comments', 'post_created', 'post_score', 'post_distinguished',
                                  'original_content', 'upvote_ratio'])
    posts['post_created'] = pd.to_datetime(posts['post_created'], unit='s')
    posts['scrape_time'] = datetime.now()
    posts[['subreddit', 'post_id', 'title', 'post_author',
           'post_body', 'url', 'post_permalink']] = posts[['subreddit', 'post_id', 'title', 'post_author',
                                                           'post_body', 'url', 'post_permalink']].astype(str)
    return posts


def get_subreddit(sub, sort_type, time_limit, post_limit):
    '''
    GRAB REDDIT POSTS BY SUBREDDIT
    sub = subreddits
    sort_type = 'hot', 'top', 'new', 'gilded', 'rising', 'controversial'
    time_limit = 'all', 'hour', 'day', 'week', 'month', 'year'
    post_limit = 1000 maximum
    '''
    subreddit = reddit.subreddit(sub)
    posts = []
    if sort_type == "top":
        for post in subreddit.top(time_filter=time_limit, limit=post_limit):
            posts.append([post.subreddit, post.id, post.title, post.selftext, post.author, post.url, post.permalink,
                          post.num_comments, post.created, post.score, post.distinguished, post.is_original_content,
                          post.upvote_ratio])

    if sort_type == "hot":
        for post in subreddit.hot(time_filter=time_limit, limit=post_limit):
            posts.append([post.subreddit, post.id, post.title, post.selftext, post.author, post.url, post.permalink,
                          post.num_comments, post.created, post.score, post.distinguished, post.is_original_content,
                          post.upvote_ratio])

    if sort_type == "new":
        for post in subreddit.new(limit=post_limit):
            posts.append([post.subreddit, post.id, post.title, post.selftext, post.author, post.url, post.permalink,
                          post.num_comments, post.created, post.score, post.distinguished, post.is_original_content,
                          post.upvote_ratio])

    if sort_type == "rising":
        for post in subreddit.rising(limit=post_limit):
            posts.append([post.subreddit, post.id, post.title, post.selftext, post.author, post.url, post.permalink,
                          post.num_comments, post.created, post.score, post.distinguished, post.is_original_content,
                          post.upvote_ratio])

    if sort_type == "controversial":
        for post in subreddit.controversial(time_filter=time_limit, limit=post_limit):
            posts.append([post.subreddit, post.id, post.title, post.selftext, post.author, post.url, post.permalink,
                          post.num_comments, post.created, post.score, post.distinguished, post.is_original_content,
                          post.upvote_ratio])

    posts = pd.DataFrame(posts,
                         columns=['subreddit', 'post_id', 'title', 'post_body', 'post_author', 'url', 'post_permalink',
                                  'num_comments', 'post_created', 'post_score', 'post_distinguished',
                                  'original_content', 'upvote_ratio'])
    posts['post_created'] = pd.to_datetime(posts['post_created'], unit='s')
    posts['scrape_time'] = datetime.now()
    posts[['subreddit', 'post_id', 'title', 'post_author',
           'post_body', 'url', 'post_permalink']] = posts[['subreddit', 'post_id', 'title', 'post_author',
                                                           'post_body', 'url', 'post_permalink']].astype(str)
    return posts

def get_reddit_comments(post_id):
    submission = reddit.submission(id = post_id)
    comment = []
    for top_level in submission.comments:
        if isinstance(top_level, MoreComments):
            continue
        comment.append([top_level.subreddit, top_level.submission, top_level.id, top_level.parent_id, top_level.author, top_level.permalink, top_level.body, top_level.created, top_level.score, top_level.distinguished])
    comments = pd.DataFrame(comment,columns=['subreddit', 'post_id', 'comment_id', 'parent_id', 'comment_author', 'comment_permalink', 'comment_body', 'comment_created', 'comment_score', 'comment_distinguished'])
    comments['comment_created'] = pd.to_datetime(comments['comment_created'],unit='s')
    comments['scrape_time'] = datetime.now()
    return comments


''' Designate input parameters for functions
topic = topic of interest (label)
search terms = key terms to search ALL of reddit
subreddits = subreddits to collect
search_sort_type = 'relevance', 'hot', 'top', 'new', 'comments'
sub_sort_type = 'hot', 'top', 'new', 'gilded', 'rising', 'controversial'
time_limit = 'all', 'hour', 'day', 'week', 'month', 'year'
post_limit = 10
'''
if __name__ == "__main__":
    topic = "my_topic"

    search_terms = ['fish']

    subreddits = ['worldnews']

    sub_sort_type = 'new' #, 'top', 'new', 'gilded', 'rising', 'controversial'
    search_sort_type = 'relevance' #, 'hot', 'top', 'new', 'comments'
    time_limit = 'all' #, 'hour', 'day', 'week', 'month', 'year'
    post_limit = 5 #maximum of 1000

    ''' Collect posts & corresponding comments
    '''
    list_posts_df = []
    try:
        for query in search_terms:
            post_df = search_reddit(query, search_sort_type, time_limit, post_limit)
            print("Grabbed", len(post_df), "posts with search term:", query)
            list_posts_df.append(post_df)
    except:
        pass

    try:
        for sub in subreddits:
            post_df = get_subreddit(sub, sub_sort_type, time_limit, post_limit)
            print("Grabbed", len(post_df), "posts from subreddit:", sub)
            list_posts_df.append(post_df)
    except:
        pass

    new_posts = pd.concat(list_posts_df)

    # File output for posts
    filepath_csv = TODAY_DIRECTORY + "/reddit_posts_" + topic + datetime.now().strftime("%Y%m%d") + ".csv"
    new_posts.to_csv(filepath_csv, index=False)
    filepath_excel = TODAY_DIRECTORY + "/reddit_posts_" + topic + datetime.now().strftime("%Y%m%d") + ".xlsx"
    new_posts.to_excel(filepath_excel, index=False)

    post_ids = new_posts['post_id'].to_list()

    list_comment_dfs = []
    i = 0
    for post in post_ids:
        comment_df = get_reddit_comments(post)
        list_comment_dfs.append(comment_df)
        print(i, "Grabbed", len(comment_df),"comments from post id:", post)
        i += 1
    post_comments = pd.concat(list_comment_dfs)

    # File output for comment
    com_filepath_csv = TODAY_DIRECTORY + "/reddit_comments_" + topic + datetime.now().strftime("%Y%m%d") + ".csv"
    post_comments.to_csv(com_filepath_csv, index=False)
    com_filepath_excel = TODAY_DIRECTORY + "/reddit_comments_" + topic + datetime.now().strftime("%Y%m%d") + ".xlsx"
    post_comments.to_excel(com_filepath_excel, index=False)
